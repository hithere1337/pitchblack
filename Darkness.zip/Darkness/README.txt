Darkness Texture Pack for Minecraft (version 1)

It may say that it is outdated, but it should work with any version.
Optifine is required!

